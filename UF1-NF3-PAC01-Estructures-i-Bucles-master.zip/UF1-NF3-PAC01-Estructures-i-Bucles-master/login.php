<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    session_unset();
    ?>
    <html>
     <head>
      <title>Please Log In</title>
     </head>
     <body>
      <form method="post" action="ejercicio1.php">
       <p>Enter your text: 
        <input type="text" name="text"/>
       </p>
       <p>Enter your color:
        <input type="color" name="color"/>
       </p>
       <p>Enter your font choice:</p>
       <select name="tipografía">
            <option>Arial</option>
            <option>Sans Serif</option>
            <option>Futura</option>
            <option>Bodoni</option>
            <option>Trajan</option>
       </p>
       </select>
       <p>Enter your size: 
        <input type="range" min="0" max="100" name="tamaño"/>
       </p>
       <p>Checkbox: 
        <input type="checkbox" name="checkbox"/>
       </p>
       <p>
        <input type="submit" name="submit" value="Submit"/>
       </p>
      </form>
     </body>
    </html>