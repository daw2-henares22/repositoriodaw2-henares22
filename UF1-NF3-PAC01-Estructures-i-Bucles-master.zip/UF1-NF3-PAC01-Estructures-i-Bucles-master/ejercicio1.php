<html>
<head>
<title> Welcome!</title>
</head>
<body>
<div style="text-align: center">
<style>
    .colores{
        color:<?php echo $_POST['color'];?>;
        font-family:<?php echo $_POST['tipografía'];?>;
        font-size:<?php echo $_POST['tamaño'];?>;
    }
</style>
<p class="colores"> Welcome to my movie review site!<br/>
<?php
session_start();
if(!isset($_POST['checkbox'])){
    $mCOOKIE = $_POST['checkbox']=true;
}else{
    $mCOOKIE = $_POST['checkbox']=false;
}
echo "<br/>";

//Ejercicio 5
if($mCOOKIE==true){
    setcookie("text",time()+60);
    setcookie("color",time()+60);
    setcookie("tipografía",time()+60);
    setcookie("tamaño",time()+60);
}else{
    echo "Error de cookie";
}
echo "<br/>";

if(isset($_POST['text'])){
    echo $_POST['text'];
    echo "<br/>";
}else{
    $_POST['text'] = "Nada";
}

if(isset($_POST['color'])){
    echo $_POST['color'];
    echo "<br/>";
}else{
    $_POST['color'] = "Nada";
}

if(isset($_POST['tipografía'])){
    echo $_POST['tipografía'];
    echo "<br/>";
}else{
    $_POST['tipografía'] = "Nada";
}

if(isset($_POST['tamaño'])){
    echo $_POST['tamaño'];
    echo "<br/>";
}else{
    $_POST['tamaño'] = "Nada";
}
?>
</p>
<?php
//Ejercicio1
date_default_timezone_set("Europe/Andorra");
echo "Two days ago it was ";
echo date ('d', strtotime('-2 days'));
echo "<br/>";
echo ("The next month is ");
echo date ('F', strtotime('+1 month'));
echo "<br/>";
echo "There are ";
function dias_hasta_fin_mes(){
    $total_mes = cal_days_in_month(CAL_GREGORIAN, date("m"), date("Y"));
    $transcurrido = date("d");
    return $total_mes - $transcurrido;
}
echo dias_hasta_fin_mes();
echo " days left in next month.";
echo "<br/>";
echo "There are ";
$mes = 12-date("m");
echo $mes;
echo " months left in the current year.";
echo "<br/>";
//Ejercicio3
function Summer(){
    $fecha = date("m");
    if($fecha>=6){
        echo "Good Summer!";
    }else if($fecha>=9){
        echo "Good Winter";
    }
}
if(!isset($_SESSION['visitante'])){
    $_SESSION['visitante'] = 1;
}else{
    $_SESSION['visitante'] += 1;
}
echo "<br/>";
echo $_SESSION['visitante'];
echo "<br/>";

//Ejercicio2
$myfavmovie = urlencode("");
echo "<a href='https://github.com/daw2-henares22/repositoriodaw2-henares22$myfavmovie'>";
echo "Site developed by: Rubén";
?>
<br/>
</div>
</body>
</html>