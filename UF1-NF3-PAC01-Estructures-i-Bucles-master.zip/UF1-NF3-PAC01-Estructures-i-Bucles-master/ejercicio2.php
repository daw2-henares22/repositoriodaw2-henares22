<?php
    echo $_COOKIE["text"];
    echo $_COOKIE["color"];
    echo $_COOKIE["tipografía"];
    echo $_COOKIE["tamaño"];
?>